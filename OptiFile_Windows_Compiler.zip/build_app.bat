@echo off
echo ==================================================
echo      Building OptiFile Desktop for Windows        
echo ==================================================

:: 1. Install dependencies
echo [1/3] Installing and upgrading required packages...
python -m pip install --upgrade pip
python -m pip install Pillow pypdf pillow-heif pyinstaller

:: 2. Compile application using PyInstaller
echo [2/3] Compiling app.py into standalone Windows executable...
pyinstaller --noconfirm --onefile --windowed --name="OptiFile" --clean app.py

:: 3. Verify output
if exist "dist\OptiFile.exe" (
    echo ==================================================
    echo 🎉 Build Successful!
    echo You can find your standalone executable at:
    echo 👉 dist\OptiFile.exe
    echo ==================================================
) else (
    echo ❌ Error: Standalone executable was not found in "dist\"
    exit /b 1
)
pause
